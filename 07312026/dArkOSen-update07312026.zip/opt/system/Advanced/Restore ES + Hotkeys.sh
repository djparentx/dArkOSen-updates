#!/bin/bash

OGAGE="/usr/local/bin"
ES="/usr/bin/emulationstation"

sudo systemctl stop ogage.service

sudo cp -f $OGAGE/ogage.darkosen $OGAGE/ogage
sudo cp -f $ES/emulationstation.darkosen $ES/emulationstation

sudo chmod +x $OGAGE/ogage
sudo chmod +x $ES/emulationstation

sudo systemctl start ogage.service
