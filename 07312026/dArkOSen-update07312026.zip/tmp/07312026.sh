#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

LOG_FILE="/home/ark/dArkOSen-update07312026.log"

printf "Running update script" >> "$LOG_FILE" 2>&1

# permissions
chmod +x /usr/local/bin/fn_menu_watcher.sh
chmod +x /usr/bin/emulationstation/emulationstation.darkosen
chmod +x /usr/bin/emulationstation/emulationstation
chmod +x /usr/local/bin/drastic.sh
chmod +x /opt/advanceddrastic/drastic
chmod +x /opt/inttools/osk.py
chmod +x /usr/local/bin/ogage.darkosen
chmod +x /usr/local/bin/ogage
chmod -R +x /opt/system

# services
systemctl daemon-reload
systemctl enable --now fn-menu-watcher.service
systemctl start ogage.service

# fix fstab
sed -i 's|^LABEL=ROOTFS / btrfs|/dev/mmcblk0p2 / btrfs|' /etc/fstab

# fix zram autostart if loaded
[[ -f "/etc/systemd/system/zram_autostart.service" ]] && sed -i 's|^After=local-fs.target|After=systemd-udevd.service|' /etc/systemd/system/zram_autostart.service

# enable network commands in retroarch (should be on by default)
sed -i '/^network_cmd_enable/d;/^network_cmd_port/d' /home/ark/.config/retroarch/retroarch.cfg
printf 'network_cmd_enable = "true"\nnetwork_cmd_port = "55355"\n' | tee -a /home/ark/.config/retroarch/retroarch.cfg

sed -i '/^network_cmd_enable/d;/^network_cmd_port/d' /home/ark/.config/retroarch32/retroarch.cfg
printf 'network_cmd_enable = "true"\nnetwork_cmd_port = "55356"\n' | tee -a /home/ark/.config/retroarch32/retroarch.cfg

# add advanceddrastic to es_systems.cfg
awk '
BEGIN {
  block="\t<system>\n\t\t\t<name>nds</name>\n\t\t\t<fullname>NDS</fullname>\n\t\t\t<path>/roms/nds/</path>\n\t\t\t<extension>.7z .7Z .nds .NDS .zip .ZIP</extension>\n\t\t\t<command>sudo perfmax %GOVERNOR% %ROM%; nice -n -19 /usr/local/bin/drastic.sh %EMULATOR% %ROM%; sudo perfnorm</command>\n\t\t\t<emulators>\n\t\t\t\t\t<emulator name=\"advanceddrastic\">\n\t\t\t\t\t</emulator>\n\t\t\t\t\t<emulator name=\"drastic\">\n\t\t\t\t\t</emulator>\n\t\t\t</emulators>\n\t\t\t<platform>nds</platform>\n\t\t\t<theme>nds</theme>\n\t\t\t<manufacturer>Nintendo</manufacturer>\n\t\t\t<release>2004</release>\n\t\t\t<hardware>handheld</hardware>\n\t</system>"
}
/<system>/ { buf=$0 ORS; inblk=1; isnds=0; next }
inblk {
  buf = buf $0 ORS
  if ($0 ~ /<name>nds<\/name>/) isnds=1
  if ($0 ~ /<\/system>/) {
    if (isnds && buf !~ /<emulators>/) { print block }
    else { printf "%s", buf }
    inblk=0; next
  }
  next
}
{ print }
' /etc/emulationstation/es_systems.cfg > /tmp/es_systems.cfg.new && mv /tmp/es_systems.cfg.new /etc/emulationstation/es_systems.cfg

# cleanup
rm -f "/opt/system/Tools/Dave's Retro Shaders.sh"

[[ ! -f "/roms/backup/old scripts/Update-dArkOS.sh" ]] && mv -f /opt/system/System/Update.sh "/roms/backup/old scripts/Update-dArkOS.sh"
[[ -f "/roms/backup/old scripts/Update-dArkOS.sh" && -f "/opt/system/System/Update-dArkOSen.sh" ]] && mv -f /opt/system/System/Update-dArkOSen.sh /opt/system/System/Update.sh

# copy hostname
cp -f /tmp/hostname /etc/hostname
cp -f /tmp/hosts /etc/hosts

printf "Update script finished." >> "$LOG_FILE" 2>&1
sleep 1