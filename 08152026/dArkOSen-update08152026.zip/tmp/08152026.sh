#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

LOG_FILE="/home/ark/dArkOSen-update08152026.log"

exec > >(tee -a "$LOG_FILE") 2>&1
set -x

printf "Running update script" >> "$LOG_FILE" 2>&1

# install packages
dpkg -i /tmp/*.deb

# update retroarch cheats
7z x /tmp/cht.7z -o/home/ark/.config/retroarch/cheats/ -aoa
7z x /tmp/cht.7z -o/home/ark/.config/retroarch32/cheats/ -aoa

# permissions
chmod +x /usr/local/bin/finish.sh
chmod +x /usr/local/bin/saturn.sh
chmod +x /usr/local/bin/Scan_SD1p3.sh
chmod +x /usr/local/bin/Scan_SD2.sh
chmod +x /opt/drastic/drastic.bilinear
chmod +x /opt/drastic/drastic.nearest
chmod +x /opt/advanceddrastic/drastic.bilinear
chmod +x /opt/advanceddrastic/drastic.nearest
chmod +x "/opt/system/Tools/R36 SD MP4 Video Converter.sh"
chmod +x "/opt/system/Advanced/Drastic Bilinear Filter Mode.sh"
chmod +x "/opt/system/Advanced/dArkOSen_dtb_patcher_v1.2.sh"
chmod +x "/opt/system/Advanced/Update Retroarch Cheats.sh"
chmod +x "/opt/system/System/R36 Joystick Deadzone Adjuster.sh"
chmod +x "/opt/system/System/SYSTEMS Manager.sh"
chmod +x "/opt/system/System/SD Card Scan and Repair.sh"
chown -R ark:ark /home/ark/.config/retroarch/cheats/.
chown -R ark:ark /home/ark/.config/retroarch32/cheats/.
systemctl daemon-reload

# fix menu hotkey in drastic/advanced drastic
sed -i 's/^controls_a\[CONTROL_INDEX_MENU\] = .*/controls_a[CONTROL_INDEX_MENU] = 1038/' /opt/drastic/config/drastic.cfg
sed -i 's/^controls_a\[CONTROL_INDEX_MENU\] = .*/controls_a[CONTROL_INDEX_MENU] = 1038/' /opt/advanceddrastic/config/drastic.cfg

# fix Mupen64Plus hotkey conflict
sed -i -E 's|(Joy Mapping Save State = "J0B12/)B5|\1B7|; s|(Joy Mapping Load State = "J0B12/)B4|\1B6|' /home/ark/.config/mupen64plus/mupen64plus.cfg

# turn on duckstation log
sed -i 's/^LogLevel = .*/LogLevel = Debug/; s/^LogToFile = .*/LogToFile = true/' ~/.local/share/duckstation/settings.ini

# patch adc-deadzone (384 ADC)
NEW_DZ="0x180"

for dtb in /boot/rk3326-r36s-linux.dtb /boot/rk3326-r36h-linux.dtb /boot/rk3326-r45h-linux.dtb; do
    [[ -f "$dtb" ]] || continue

    dts="${dtb%.dtb}.dts"

    cp -f "$dtb" "$dtb.bak"
    dtc -I dtb -O dts -o "$dts" "$dtb"

    sed -i -E \
        "s/^([[:space:]]*button-adc-deadzone[[:space:]]*=[[:space:]]*<)[^>]+(>;)$/\1${NEW_DZ}\2/" \
        "$dts"

    dtc -I dts -O dtb -o "$dtb" "$dts"
    rm -f "$dts"
done

# cleanup
rm -f /opt/system/Advanced/dArkOSen_dtb_patcher_v1.1.sh
rm -f "/opt/system/System/Wi-Fi Manager 4.3.6.sh"
rm -f /boot/dtb/battery_values.txt
rm -rf /tmp/* /tmp/.[!.]* /tmp/..?*

printf "Update script finished." >> "$LOG_FILE" 2>&1
sleep 2