#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

UPDATE_DATE="10312026"
LOG_FILE="/home/ark/dArkOSen-update$UPDATE_DATE.log"
UPDATE_DONE="/home/ark/.config/.dArkOSen-update$UPDATE_DATE"

exec > >(tee -a "$LOG_FILE") 2>&1
set -x

printf "Running update script" >> "$LOG_FILE" 2>&1

# installs
# dpkg -i /tmp/*.deb

# permissions
chmod +x "/usr/local/bin/night_filter.sh"
chmod +x "/usr/local/bin/speak_bat_life.sh"
chmod +x "/usr/local/bin/playtimer_watchdog.sh"
chmod +x "/usr/local/bin/batt_life_verbal_warning.py"
chmod +x "/usr/local/bin/perfmax"
chmod +x "/usr/local/bin/current_volume"
chmod +x "/usr/local/bin/doom.sh"
chmod +x "/usr/local/bin/NDS.sh"
chmod +x "/usr/bin/emulationstation/emulationstation"
chmod +x "/usr/bin/emulationstation/resources/aquarium/aquarium"
chmod +x "/usr/bin/emulationstation/resources/corridors/3D_Corridors"
chmod +x "/opt/gzdoom/gzdoom"
chmod +x "/opt/dsperate/dsperate"
chmod +x "/opt/yabasanshiro/yabasanshiro-pirry"
chmod +x "/opt/system/Advanced/OTG_fix.sh"

chown ark:ark "/usr/local/bin/night_filter.sh"
chown ark:ark "/usr/local/bin/speak_bat_life.sh"
chown ark:ark "/usr/local/bin/playtimer_watchdog.sh"
chown ark:ark "/usr/local/bin/batt_life_verbal_warning.py"
chown ark:ark "/usr/local/bin/perfmax"
chown ark:ark "/usr/local/bin/current_volume"
chown ark:ark "/usr/local/bin/doom.sh"
chown ark:ark "/usr/local/bin/NDS.sh"
chown ark:ark "/usr/bin/emulationstation/emulationstation"
chown ark:ark "/usr/bin/emulationstation/resources/aquarium/aquarium"
chown ark:ark "/usr/bin/emulationstation/resources/corridors/3D_Corridors"
chown -R ark:ark "/opt/gzdoom"
chown -R ark:ark "/opt/dsperate"
chown -R ark:ark "/opt/yabasanshiro/yabasanshiro-pirry"
chown ark:ark "/opt/system/Advanced/OTG_fix.sh"

#sudo ldconfig

systemctl daemon-reload
systemctl enable --now night-filter.timer

# cleanup
rm -rf "/opt/system/Tools/ThemeMaster"*
rm -f /roms/ports/halo/config.toml

# copy kernel
# sudo cp -f "/boot/Image" "/root/Image.darkosen"

# copy ES
cp -f "/usr/bin/emulationstation/emulationstation" "/usr/bin/emulationstation/emulationstation.darkosen"

# fix verbal bat warning
mkdir -p /usr/local/bin/.asoundbackup
cp /home/ark/.asoundrcbak /usr/local/bin/.asoundbackup/.asoundrcbak.rk3326
sed -i 's|<string name="VerbalBatteryWarning" value="yes" />|<string name="VerbalBatteryWarning" value="no" />|' /home/ark/.emulationstation/es_settings.cfg
touch /home/ark/.config/.NOVERBALBATTERYWARNING

# set f10 as input hotkey in Retroarch
sed -i 's/^input_enable_hotkey = .*/input_enable_hotkey = "f10"/' /home/ark/.config/retroarch/retroarch.cfg
sed -i 's/^input_enable_hotkey = .*/input_enable_hotkey = "f10"/' /home/ark/.config/retroarch32/retroarch.cfg

# create C64 Auto Enable Focus Mode config
mkdir -p "/home/ark/.config/retroarch/config/VICE x64" && echo 'input_auto_game_focus = "1"' > "/home/ark/.config/retroarch/config/VICE x64/c64.cfg"

# add DSperate to es_systems.cfg
sed -i '/<command>sudo perfmax %GOVERNOR% %ROM%; nice -n -19 \/usr\/local\/bin\/drastic.sh %EMULATOR% %ROM%; sudo perfnorm<\/command>/s/drastic\.sh/NDS.sh/; /<emulator name="drastic">/a\					<emulator name="dsperate">\n					</emulator>' /etc/emulationstation/es_systems.cfg

# add Bully to ports gamelist.xml
if ! grep -q '<path>\./Bully - Anniversary Edition\.sh</path>' /roms/ports/gamelist.xml; then
	sed -i '/<\/gameList>/i\
	<game>\
		<path>./Bully - Anniversary Edition.sh</path>\
		<name>Bully: Anniversary Edition</name>\
		<desc>Bully is a story of one Jimmy Hopkins, whose academic success hasn'\''t been anything spectacular as he'\''s been expelled from various schools. His parents have a grand idea of sending him to Bullworth Academy which -- despite its grand name -- houses lots of other kids like Jimmy. This is the place where future dictators, murderers, and mad scientists reside. With a help of a few friends, some wits and hard-as-a-rock fists, Jimmy has to survive through one year in Bullworth Academy.</desc>\
		<image>./images/Bully - Anniversary Edition-image.jpg</image>\
		<video>./videos/Bully - Anniversary Edition-video.mp4</video>\
		<marquee>./images/Bully - Anniversary Edition-marquee.png</marquee>\
		<thumbnail>./images/Bully - Anniversary Edition-thumb.jpg</thumbnail>\
		<rating>0.9</rating>\
		<releasedate>20081021T000000</releasedate>\
		<developer>Rockstar New England</developer>\
		<publisher>Rockstar Games</publisher>\
		<genre>Adventure / RealTime 3D</genre>\
		<playcount>51</playcount>\
		<lastplayed>20261027T233723</lastplayed>\
		<gametime>14010</gametime>\
		<lastsession>101</lastsession>\
	</game>' /roms/ports/gamelist.xml
fi

# copy Bully to /roms2 if exists
if [[ -d /roms2 ]]; then
	mkdir -p /roms2/ports/bully &&
	cp -rf /roms/ports/bully/. /roms2/ports/bully &&
	cp -f "/roms/ports/Bully - Anniversary Edition.sh" "/roms2/ports/Bully - Anniversary Edition.sh" &&
	mkdir -p /roms2/ports/images /roms2/ports/videos &&
	cp -rf /roms/ports/images/. /roms2/ports/images/ &&
	cp -rf /roms/ports/videos/. /roms2/ports/videos/ &&
	if ! grep -q '<path>\./Bully - Anniversary Edition\.sh</path>' /roms2/ports/gamelist.xml; then
		sed -i '/<\/gameList>/i\
	<game>\
		<path>./Bully - Anniversary Edition.sh</path>\
		<name>Bully: Anniversary Edition</name>\
		<desc>Bully is a story of one Jimmy Hopkins, whose academic success hasn'\''t been anything spectacular as he'\''s been expelled from various schools. His parents have a grand idea of sending him to Bullworth Academy which -- despite its grand name -- houses lots of other kids like Jimmy. This is the place where future dictators, murderers, and mad scientists reside. With a help of a few friends, some wits and hard-as-a-rock fists, Jimmy has to survive through one year in Bullworth Academy.</desc>\
		<image>./images/Bully - Anniversary Edition-image.jpg</image>\
		<video>./videos/Bully - Anniversary Edition-video.mp4</video>\
		<marquee>./images/Bully - Anniversary Edition-marquee.png</marquee>\
		<thumbnail>./images/Bully - Anniversary Edition-thumb.jpg</thumbnail>\
		<rating>0.9</rating>\
		<releasedate>20081021T000000</releasedate>\
		<developer>Rockstar New England</developer>\
		<publisher>Rockstar Games</publisher>\
		<genre>Adventure / RealTime 3D</genre>\
		<playcount>51</playcount>\
		<lastplayed>20261027T233723</lastplayed>\
		<gametime>14010</gametime>\
		<lastsession>101</lastsession>\
	</game>' /roms2/ports/gamelist.xml
	fi
fi

# copy Halo to /roms2 if exists
if [[ -d /roms2 ]]; then
	mkdir -p /roms2/ports/halo
	cp -rf /roms/ports/halo/. /roms2/ports/halo/
	cp -f "/roms/ports/Halo - Combat Evolved.sh" "/roms2/ports/Halo - Combat Evolved.sh"
	rm -f /roms2/ports/halo/config.toml
fi

# refesh modules
depmod -a

printf "Update script finished." >> "$LOG_FILE" 2>&1
touch "$UPDATE_DONE"
printf "\nUpdate successful" >> "$LOG_FILE" 2>&1

printf "\nUpdate boot text to reflect current version of dArkOSen\n" | tee -a "$LOG_FILE"
sed -i "/title\=/c\title\=dArkOSen ($UPDATE_DATE)" /usr/share/plymouth/themes/text.plymouth
echo "$UPDATE_DATE" > /home/ark/.config/.VERSION

sleep 2