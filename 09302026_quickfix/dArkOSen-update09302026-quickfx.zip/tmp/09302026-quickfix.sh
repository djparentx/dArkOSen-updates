#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

UPDATE_DATE="09302026-quickfix"
LOG_FILE="/home/ark/dArkOSen-update$UPDATE_DATE.log"
UPDATE_DONE="/home/ark/.config/.dArkOSen-update$UPDATE_DATE"

exec > >(tee -a "$LOG_FILE") 2>&1
set -x

printf "Running update script" >> "$LOG_FILE" 2>&1

# permissions
chmod +x "/opt/retroarch/bin/retroarch32"
chmod +x "/usr/local/bin/retrorun32"
chown ark:ark "/usr/local/bin/retrorun32"
chown ark:ark "/opt/retroarch/bin/retroarch32"

printf "Update script finished." >> "$LOG_FILE" 2>&1
touch "$UPDATE_DONE"
printf "\nUpdate successful" >> "$LOG_FILE" 2>&1

printf "\nUpdate boot text to reflect current version of dArkOSen\n" | tee -a "$LOG_FILE"
sed -i "/title\=/c\title\=dArkOSen ($UPDATE_DATE)" /usr/share/plymouth/themes/text.plymouth
echo "$UPDATE_DATE" > /home/ark/.config/.VERSION

sleep 2