#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

UPDATE_DATE="09302026b"
LOG_FILE="/home/ark/dArkOSen-update$UPDATE_DATE.log"
UPDATE_DONE="/home/ark/.config/.dArkOSen-update$UPDATE_DATE"

exec > >(tee -a "$LOG_FILE") 2>&1
set -x

printf "Running update script" >> "$LOG_FILE" 2>&1

# permissions
chmod +x "/opt/retroarch/bin/retroarch32"
chmod +x "/usr/local/bin/retrorun32"
chmod +x "/usr/local/bin/retrorun"
chown ark:ark "/usr/local/bin/retrorun32"
chown ark:ark "/usr/local/bin/retrorun"
chown ark:ark "/opt/retroarch/bin/retroarch32"

# activate custom armhf alsa-lib 1.2.8 (stock t64 build has no audio on kernel 4.4.189)
printf "\nActivate custom armhf libasound (1.2.8)\n" | tee -a "$LOG_FILE"
LIBDIR=/usr/lib/arm-linux-gnueabihf
if ! dpkg-divert --list "$LIBDIR/libasound.so.2.0.0" | grep -q distrib; then
  dpkg-divert --local --no-rename --divert "$LIBDIR/libasound.so.2.0.0.distrib" --add "$LIBDIR/libasound.so.2.0.0" | tee -a "$LOG_FILE"
  -a "$LOG_FILE"
fi
chmod 644 "$LIBDIR/libasound.so.2.0.0"
ln -sfv libasound.so.2.0.0 "$LIBDIR/libasound.so.2" | tee -a "$LOG_FILE"
ln -sfv libasound.so.2.0.0 "$LIBDIR/libasound.so" | tee -a "$LOG_FILE"
ldconfig -X
sha1sum "$LIBDIR/libasound.so.2.0.0" | tee -a "$LOG_FILE"

printf "Update script finished." >> "$LOG_FILE" 2>&1
touch "$UPDATE_DONE"
printf "\nUpdate successful" >> "$LOG_FILE" 2>&1

printf "\nUpdate boot text to reflect current version of dArkOSen\n" | tee -a "$LOG_FILE"
sed -i "/title\=/c\title\=dArkOSen ($UPDATE_DATE)" /usr/share/plymouth/themes/text.plymouth
echo "$UPDATE_DATE" > /home/ark/.config/.VERSION

sleep 2