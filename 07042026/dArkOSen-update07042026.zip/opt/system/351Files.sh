#!/bin/bash

cd /opt/351Files
sudo ./351Files-sd2 2>&1 1>351Files.log
printf "\033c" >> /dev/tty1
